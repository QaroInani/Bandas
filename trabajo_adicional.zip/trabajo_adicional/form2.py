# -*- coding: utf-8 -*-

from PySide import QtCore, QtGui

class Ui_Form2(object):

    def setupUi(self, Form2):
        Form2.setObjectName("Form2")
        Form2.resize(400, 200)
        Form2.setMaximumSize(QtCore.QSize(400, 200))
        self.formLayoutWidget = QtGui.QWidget(Form2)
        self.formLayoutWidget.setGeometry(QtCore.QRect(20, 10, 250, 70))
        self.formLayoutWidget.setObjectName("formLayoutWidget")
        self.formLayout = QtGui.QFormLayout(self.formLayoutWidget)
        self.formLayout.setFieldGrowthPolicy(QtGui.QFormLayout.AllNonFixedFieldsGrow)
        self.formLayout.setLabelAlignment(QtCore.Qt.AlignRight|\
             QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.formLayout.setFormAlignment(QtCore.Qt.AlignCenter)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.formLayout.setObjectName("formLayout")
 
        #Label containing the name of the style
        self.label = QtGui.QLabel(self.formLayoutWidget)
        self.label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label.setAlignment(QtCore.Qt.AlignRight|\
             QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.label.setObjectName("label")
        self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.label)
        self.name_style = QtGui.QLineEdit(self.formLayoutWidget)
        self.name_style.setMinimumSize(QtCore.QSize(100, 25))
        self.name_style.setMaximumSize(QtCore.QSize(100, 25))
        self.name_style.setObjectName("Name Style")
        self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.name_style)
 
        self.horizontalLayoutWidget = QtGui.QWidget(Form2)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(100, 100, 200, 30))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtGui.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")


	#Buttons for accept or cancel the action
        self.btn_add = QtGui.QPushButton(self.horizontalLayoutWidget)
        self.btn_add.setObjectName("btn_add")
        self.horizontalLayout.addWidget(self.btn_add)
        self.btn_cancel = QtGui.QPushButton(self.horizontalLayoutWidget)
        self.btn_cancel.setObjectName("btn_cancel")
        self.horizontalLayout.addWidget(self.btn_cancel)

        #Message of information
        self.message = QtGui.QLabel(Form2)
        self.message.setGeometry(QtCore.QRect(40, 250, 280, 20))
        self.message.setText("")
        self.message.setTextFormat(QtCore.Qt.AutoText)
        self.message.setScaledContents(False)
        self.message.setAlignment(QtCore.Qt.AlignCenter)
        self.message.setObjectName("message")
        self.retranslateUi(Form2)
        QtCore.QMetaObject.connectSlotsByName(Form2)


    def retranslateUi(self, Form2):
        Form2.setWindowTitle(QtGui.QApplication.translate("Form2", "Agregar Estilo", 
None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Form2", "Nombre Estilo:", 
None, QtGui.QApplication.UnicodeUTF8))    
        self.btn_add.setText(QtGui.QApplication.translate("Form2", "Aceptar", 
None, QtGui.QApplication.UnicodeUTF8))
        self.btn_cancel.setText(QtGui.QApplication.translate("Form2", "Cancelar", 
None, QtGui.QApplication.UnicodeUTF8))

