# -*- coding: utf-8 -*-
import sqlite3


def connect():
    #Connect with the database
    conn = sqlite3.connect("database0.db")
    conn.row_factory = sqlite3.Row
    return conn


def add_band(name_band, foundation, members, hits, discs, active, styles):
    #Add a new band to the table 'bands' on the database
    if name_band == "":
        print("no name")#No name was entered
    else:
        success = False
        conn = connect()
        c = conn.cursor()
        values = [name_band, foundation, members, hits, discs, active, styles]
        query = "INSERT INTO bands (name_band, fk_id_styles, foundation, \
                 members, hits, discs, active) VALUES(?,?,?,?,?,?,?)"
        try:
            result = c.execute(query, values)
            success = True
            conn.commit()
        except sqlite3.Error as e:
            success = False
            print "Error: ", e.args[0]
        conn.close()
        return success


def edit_band(id_band, name_band, foundation, members, hits, discs, active, 
              styles):
    #Edit the selected row band 
    if name_band == "":
        print("no name")#No name was entered
    else: 
        success = False
        conn = connect()
        c = conn.cursor()
        values = [name_band, foundation, members, hits, discs, active, 
                 styles, id_band]
        query = """UPDATE bands SET name_band = ?, fk_id_styles = ?, 
                foundation = ?, members = ?, hits = ?, discs = ?, 
                active = ? WHERE id_band = ?"""
        try:
            result = c.execute(query, values)
            success = True
            conn.commit()
        except sqlite3.Error as e:
            success = False
            print "Error: ", e.args[0]
        conn.close()
        return success


def delete(name_band):
    #Delete the selected row band
    success = False
    conn = connect()
    c = conn.cursor()
    query = "DELETE FROM bands WHERE name_band = ?"
    try:
        result = c.execute(query, [name_band])
        conn.commit()
        success = True
    except sqlite3.Error as e:
        success = False
        print "Error:", e.args[0]
    conn.close()
    return success


def add_style(name_style, styles):
    #Add a new style to the table 'bands' on the database
    if name_style == "":
        print("no name")#No name was entered
    else:
        success = False
        conn = connect()
        c = conn.cursor()
        values = [name_style, styles]
        query = "INSERT INTO styles (name_style) VALUES(?)"
        try:
            result = c.execute(query, values)
            success = True
            conn.commit()
        except sqlite3.Error as e:
            success = False
            print "Error: ", e.args[0]
        conn.close()
        return success

def edit_style(name_style,styles):
    #Edit the selected row style
    if name_style == "":
        print("no name")#No name was entered
    else: 
        success = False
        conn = connect()
        c = conn.cursor()
        values = [name_style, styles]
        query = """UPDATE styles SET name_style = ? WHERE id_style = ?"""
        try:
            result = c.execute(query, values)
            success = True
            conn.commit()
        except sqlite3.Error as e:
            success = False
            print "Error: ", e.args[0]
        conn.close()
        return success

def delete2(name_style):
    #Delete the selected row style
    success = False
    conn = connect()
    c = conn.cursor()
    query = "DELETE FROM styles WHERE name_style = ?"
    try:
        result = c.execute(query, [name_style])
        conn.commit()
        success = True
    except sqlite3.Error as e:
        success = False
        print "Error:", e.args[0]
    conn.close()
    return success


def get_id_styles(styles):
    #Get the id of the style on the database 
    conn = connect()
    c = conn.cursor()
    query = """SELECT id_styles FROM styles WHERE name_style = ?"""
    c.execute(query, [styles])
    id_styles = c.fetchone()
    result = id_styles[0]
    conn.close()
    return result


def get_band(name_band):
    #Get a band in the table 'bands'
    conn = connect()
    c = conn.cursor()
    query = "SELECT * FROM bands WHERE name_band = ?"
    result = c.execute(query, [name_band])
    band = result.fetchone()
    conn.close()
    return band


def get_bands():
    #Get all bands in the table 'bands'
    conn = connect()
    c = conn.cursor()
    query = """SELECT a.id_band, a.name_band, a.foundation, a.members, a.hits,
            a.discs, a.active, b.name_style as 'styles'
            FROM bands a, styles b WHERE a.fk_id_styles = b.id_styles"""
    result = c.execute(query)
    bands = result.fetchall()
    conn.close()
    return bands

def get_styles():
    #Get all styles in the table 'styles'
    conn = connect()
    c = conn.cursor()
    query = """SELECT * FROM styles"""
    result = c.execute(query)
    styles = result.fetchall()
    conn.close()
    return styles 

def get_id_band(name_band):
    #Get the id of the band of the table 'bands'
    conn = connect()
    c = conn.cursor()
    query = """SELECT id_band FROM bands WHERE name_band = ?"""
    c.execute(query, [name_band])
    id_band = c.fetchone()
    result = id_band[0]
    conn.close()
    return result


def get_band_by_style(id_styles):
    #Get all the bands of same style
    conn = connect()
    c = conn.cursor()
    query = """SELECT a.id_band, a.name_band, a.foundation, a.members, a.hits,
            a.discs, a.active, b.name_style as 'styles'
            FROM bands a, styles b WHERE a.fk_id_styles = b.id_styles
            AND a.fk_id_styles = ?"""
    result = c.execute(query, [id_styles])
    bands = result.fetchall()
    conn.close()
    return bands

    
def get_bands_name():
    #Get the name of the all bands on table 'bands'
    conn = connect()
    c = conn.cursor()
    query = """SELECT * FROM bands"""
    result = c.execute(query)
    band = result.fetchall()
    wlist = []
    for row in range(len(band)):
        for word in range(1,7):
           wlist.append(str(band[row][word]))
    #style = get_id_styles()
    conn.close()
    return wlist


def search_band(word):
    #Search the word in the tables and return the band with this word
    conn = connect()
    c = conn.cursor()
    query = """SELECT a.id_band, a.name_band, a.foundation, a.members, a.hits,
            a.discs, a.active, b.name_style as 'styles'
            FROM bands a, styles b WHERE a.fk_id_styles = b.id_styles
            AND (a.name_band LIKE '%'||?||'%' OR a.foundation LIKE '%'||?||'%'
            OR a.members LIKE '%'||?||'%' OR a.hits LIKE '%'||?||'%' 
            OR a.discs LIKE '%'||?||'%'OR a.active LIKE  '%' ||?||'%')"""

    result = c.execute(query, [word, word, word, word, word, word])
    band = result.fetchall()
    conn.close()
    return band


if __name__ == "__main__":

    band = get_band()
    for bands in band:
        print bands['name_band']




