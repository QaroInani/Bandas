#!/usr/bin/python
# ­*­ coding: utf­8 ­*­

from PySide import QtGui, QtCore

import controller
from form2 import Ui_Form2

class Form2(QtGui.QDialog):

    def __init__(self, parent=None, name_style=None):
        QtGui.QDialog.__init__(self, parent)
        self.ui =  Ui_Form2()
        self.ui.setupUi(self)
        style = controller.get_styles()
        if name_style is None:
            self.ui.btn_add.clicked.connect(self.add)
        else:
            self.setWindowTitle(u"Editar Estilo")
            self.name_style = name_style
            style_data = controller.get_styles(name_style)
            self.ui.name_style.setText(style_data["name_style"])
            self.ui.btn_add.clicked.connect(self.edit)
        self.ui.btn_cancel.clicked.connect(self.cancel)


    def add(self):
        #Take the values from the ui form 
        #and add the new style to the database
        name_style = self.ui.name_style.text()
        result = controller.add_style(name_style)
        if result:
            self.reject()
            self.ui.msgBox = QtGui.QMessageBox.information(self, 
                             u'Información',
                             u"El registro fue creado con éxito")
        else:
            self.ui.message.setText("Error al crear registro")


    def edit(self):
        #Take the values of a band and save the edited values
        name_style = self.ui.name_style.text()
        #styles = self.ui.styles.currentText()
        #id_styles = controller.get_id_styles(name_style)
        result = controller.edit_style(name_style)
        if result:
            self.reject()
            self.ui.msgBox = QtGui.QMessageBox.information(self, 
                             u'Información',
                             u"El registro fue modificado con éxito")
        else:
            self.ui.message.setText("Error al modificar registro")
    
    def cancel(self):
        #Cancel the operation on the ui form
        self.reject()

