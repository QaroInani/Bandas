# -*- coding: utf-8 -*-

from PySide import QtCore, QtGui

class Ui_Form(object):

    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(700, 320)
        Form.setMaximumSize(QtCore.QSize(700, 320))
        self.formLayoutWidget = QtGui.QWidget(Form)
        self.formLayoutWidget.setGeometry(QtCore.QRect(20, 10, 600, 170))
        self.formLayoutWidget.setObjectName("formLayoutWidget")
        self.formLayout = QtGui.QFormLayout(self.formLayoutWidget)
        self.formLayout.setFieldGrowthPolicy(QtGui.QFormLayout.AllNonFixedFieldsGrow)
        self.formLayout.setLabelAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.formLayout.setFormAlignment(QtCore.Qt.AlignCenter)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.formLayout.setObjectName("formLayout")
 
        #Label containing the name of the band
        self.label = QtGui.QLabel(self.formLayoutWidget)
        self.label.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label.setAlignment(QtCore.Qt.AlignRight|QtCore.Qt.AlignTrailing|QtCore.Qt.AlignVCenter)
        self.label.setObjectName("label")
        self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.label)
        self.name_band = QtGui.QLineEdit(self.formLayoutWidget)
        self.name_band.setMinimumSize(QtCore.QSize(400, 25))
        self.name_band.setMaximumSize(QtCore.QSize(400, 25))
        self.name_band.setObjectName("Name Band")
        self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.name_band)

        #Label containing the style of the band
        self.label_2 = QtGui.QLabel(self.formLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.formLayout.setWidget(1, QtGui.QFormLayout.LabelRole, self.label_2)
        self.styles = QtGui.QComboBox(self.formLayoutWidget)
        self.styles.setMinimumSize(QtCore.QSize(400, 25))
        self.styles.setMaximumSize(QtCore.QSize(400, 25))
        self.styles.setObjectName("Styles")
        self.formLayout.setWidget(1, QtGui.QFormLayout.FieldRole, self.styles)

        #Label containing the foundation year of the band
        self.label_3 = QtGui.QLabel(self.formLayoutWidget)
        self.label_3.setObjectName("label_3")
        self.formLayout.setWidget(2, QtGui.QFormLayout.LabelRole, self.label_3)
        self.foundation = QtGui.QSpinBox(self.formLayoutWidget)
        self.foundation.setMinimumSize(QtCore.QSize(400, 25))
        self.foundation.setMaximumSize(QtCore.QSize(400, 25))
        self.foundation.setMaximum(2013)
        self.foundation.setObjectName("Foundation")
        self.formLayout.setWidget(2, QtGui.QFormLayout.FieldRole, self.foundation) 

        #Label containing the memnbers of the band
        self.label_4 = QtGui.QLabel(self.formLayoutWidget)
        self.label_4.setObjectName("label_4")
        self.formLayout.setWidget(3, QtGui.QFormLayout.LabelRole, self.label_4)
        self.members = QtGui.QLineEdit(self.formLayoutWidget)
        self.members.setMinimumSize(QtCore.QSize(400, 25))
        self.members.setMaximumSize(QtCore.QSize(400, 25))
        self.members.setObjectName("Members")
        self.formLayout.setWidget(3, QtGui.QFormLayout.FieldRole, self.members)

        #Label containing the hits of the band
        self.label_5 = QtGui.QLabel(self.formLayoutWidget)
        self.label_5.setObjectName("label_5")
        self.formLayout.setWidget(4, QtGui.QFormLayout.LabelRole, self.label_5)
        self.hits = QtGui.QLineEdit(self.formLayoutWidget)
        self.hits.setMinimumSize(QtCore.QSize(400, 25))
        self.hits.setMaximumSize(QtCore.QSize(400, 25))
        self.hits.setObjectName("Hits")
        self.formLayout.setWidget(4, QtGui.QFormLayout.FieldRole, self.hits)

        #Label containing the discs of the band
        self.label_6 = QtGui.QLabel(self.formLayoutWidget)
        self.label_6.setObjectName("label_6")
        self.formLayout.setWidget(5, QtGui.QFormLayout.LabelRole, self.label_6)
        self.discs = QtGui.QLineEdit(self.formLayoutWidget)
        self.discs.setMinimumSize(QtCore.QSize(400, 25))
        self.discs.setMaximumSize(QtCore.QSize(400, 25))
        self.discs.setObjectName("Discs")
        self.formLayout.setWidget(5, QtGui.QFormLayout.FieldRole, self.discs) 

        #Label containing the active state of the band
        self.label_7 = QtGui.QLabel(self.formLayoutWidget)
        self.label_7.setObjectName("label_7")
        self.formLayout.setWidget(6, QtGui.QFormLayout.LabelRole, self.label_7)
        self.active = QtGui.QLineEdit(self.formLayoutWidget)
        self.active.setMinimumSize(QtCore.QSize(400, 25))
        self.active.setMaximumSize(QtCore.QSize(400, 25))
        self.active.setObjectName("Active")
        self.formLayout.setWidget(6, QtGui.QFormLayout.FieldRole, self.active)
 
        self.horizontalLayoutWidget = QtGui.QWidget(Form)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(210, 210, 300, 30))
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayout = QtGui.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")

	#Buttons for accept or cancel the action
        self.btn_add = QtGui.QPushButton(self.horizontalLayoutWidget)
        self.btn_add.setObjectName("btn_add")
        self.horizontalLayout.addWidget(self.btn_add)
        self.btn_cancel = QtGui.QPushButton(self.horizontalLayoutWidget)
        self.btn_cancel.setObjectName("btn_cancel")
        self.horizontalLayout.addWidget(self.btn_cancel)

        #Message of information
        self.message = QtGui.QLabel(Form)
        self.message.setGeometry(QtCore.QRect(40, 250, 361, 20))
        self.message.setText("")
        self.message.setTextFormat(QtCore.Qt.AutoText)
        self.message.setScaledContents(False)
        self.message.setAlignment(QtCore.Qt.AlignCenter)
        self.message.setObjectName("message")
        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)


    def retranslateUi(self, Form):
        Form.setWindowTitle(QtGui.QApplication.translate("Form", "Agregar Banda", None,                        QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Form", "Nombre Banda:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Form", "Estilo asociado:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("Form", "Año Fundación:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("Form", "Miembros:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_5.setText(QtGui.QApplication.translate("Form", "Éxitos", None, QtGui.QApplication.UnicodeUTF8))
        self.label_6.setText(QtGui.QApplication.translate("Form", "Discos", None, QtGui.QApplication.UnicodeUTF8))
        self.label_7.setText(QtGui.QApplication.translate("Form", "Vigente (SI/NO)", None, QtGui.QApplication.UnicodeUTF8))
        self.btn_add.setText(QtGui.QApplication.translate("Form", "Aceptar", None, QtGui.QApplication.UnicodeUTF8))
        self.btn_cancel.setText(QtGui.QApplication.translate("Form", "Cancelar", None, QtGui.QApplication.UnicodeUTF8))

