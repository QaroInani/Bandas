#!/usr/bin/python
# ­*­ coding: utf­8 ­*­

from PySide import QtGui, QtCore

import controller
from form import Ui_Form

class Form(QtGui.QDialog):

    def __init__(self, parent=None, name_band=None):
        QtGui.QDialog.__init__(self, parent)
        self.ui =  Ui_Form()
        self.ui.setupUi(self)
        style = controller.get_styles()
        for styles in style:
            self.ui.styles.addItem(styles["name_style"], styles["id_styles"])
        if name_band is None:
            self.ui.btn_add.clicked.connect(self.add)
        else:
            self.setWindowTitle(u"Editar Banda")
            self.name_band = name_band
            band_data = controller.get_band(name_band)
            self.ui.name_band.setText(band_data["name_band"])
            self.ui.styles.currentText()
            self.ui.foundation.setValue(band_data["foundation"])
            self.ui.members.setText(band_data["members"])
            self.ui.hits.setText(band_data["hits"])
            self.ui.discs.setText(band_data["discs"])
            self.ui.active.setText(band_data["active"])
            self.ui.btn_add.clicked.connect(self.edit)
        self.ui.btn_cancel.clicked.connect(self.cancel)


    def add(self):
        #Take the values from the ui form and add the new band to the database
        name_band = self.ui.name_band.text()
        styles = self.ui.styles.currentText()
        id_styles = controller.get_id_styles(styles)
        foundation = self.ui.foundation.value()
        members = self.ui.members.text()
        hits = self.ui.hits.text()
        discs = self.ui.discs.text()
        active = self.ui.active.text()
        if active == "SI" or active == "NO": 
            result = controller.add_band(name_band, id_styles, foundation,
                     members, hits, discs, active)
            if result:
                self.reject()
            else:
               self.ui.message.setText("Debe ingresar el nombre de la banda..")
        else:
            self.ui.message.setText("Vigente debe ser SI/NO (en mayusculas)")


    def edit(self):
        #Take the values of a band and save the edited values
        id_band = controller.get_id_band(self.name_band)
        name_band = self.ui.name_band.text()
        styles = self.ui.styles.currentText()
        id_styles = controller.get_id_styles(styles)
        foundation = self.ui.foundation.value()
        members = self.ui.members.text()
        hits = self.ui.hits.text()
        discs = self.ui.discs.text()
        active = self.ui.active.text()
        if active == "SI" or active == "NO":
            result = controller.edit_band(id_band, name_band, id_styles,
                     foundation, members, hits, discs, active)
            if result:
                self.reject()
            else:
                self.ui.message.setText("Debe ingresar el nombre de la banda..")
        else:
            self.ui.message.setText("Vigente debe ser SI/NO (en mayusculas)")
    
    def cancel(self):
        #Cancel the operation on the ui form
        self.reject()

