#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

from PySide import QtGui, QtCore
import controller
from mainwindow import Ui_MainWindow
import view_form


class Main(QtGui.QWidget): #Main UI screen

    def __init__(self):
    #Sets up the UI
        super(Main, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.load_bands_by_search()
        self.load_styles()
        self.load_bands()
        self.set_listeners()
        self.show()
	print("compila")


    def load_styles(self):
    #Loads styles from the database for the combobox
        style = controller.get_styles()
        self.ui.selectStyle.addItem("Todos", -1)
        for styles in style: #Add styles to the ComboBox
            self.ui.selectStyle.addItem(styles["name_style"], 
                 styles["id_styles"])
        self.ui.selectStyle.setEditable(False)


    def load_bands(self, band=None):
    #Loads bands from database for display
        if band is None:
            band = controller.get_bands()
        self.model = QtGui.QStandardItemModel(len(band), 6)
        self.model.setHorizontalHeaderItem(0, QtGui.QStandardItem(u"Banda"))
        self.model.setHorizontalHeaderItem(1, QtGui.QStandardItem(u"Estilo"))
        self.model.setHorizontalHeaderItem(2, QtGui.QStandardItem(u"Fundación"))
        self.model.setHorizontalHeaderItem(3, QtGui.QStandardItem(u"Integrantes"))
        self.model.setHorizontalHeaderItem(4, QtGui.QStandardItem(u"Éxitos"))
        self.model.setHorizontalHeaderItem(5, QtGui.QStandardItem(u"Discos"))
        self.model.setHorizontalHeaderItem(6, QtGui.QStandardItem(u"Vigente"))
     

        r = 0
        for row in band:
            index = self.model.index(r, 0, QtCore.QModelIndex())
            self.model.setData(index, row['name_band'])
            index = self.model.index(r, 1, QtCore.QModelIndex())
            self.model.setData(index, row['styles'])
            index = self.model.index(r, 2, QtCore.QModelIndex())
            self.model.setData(index, row['foundation'])
            index = self.model.index(r, 3, QtCore.QModelIndex())
            self.model.setData(index, row['members'])
            index = self.model.index(r, 4, QtCore.QModelIndex())
            self.model.setData(index, row['hits'])
            index = self.model.index(r, 5, QtCore.QModelIndex())
            self.model.setData(index, row['discs'])
            index = self.model.index(r, 6, QtCore.QModelIndex())
            self.model.setData(index, row['active'])
            
            r = r+1

        self.ui.table.setModel(self.model)
        self.ui.table.setColumnWidth(0, 78)
        self.ui.table.setColumnWidth(1, 100)
        self.ui.table.setColumnWidth(2, 82)
        self.ui.table.setColumnWidth(3, 145)
        self.ui.table.setColumnWidth(4, 145)
        self.ui.table.setColumnWidth(5, 100)
        self.ui.table.setColumnWidth(6, 93)

    def load_bands_by_style(self):
    #Sets up the search by style with a ComboBox
        id_styles = self.ui.selectStyle.itemData(self.ui.selectStyle.currentIndex())
        if id_styles == -1: #if option selected is "todos" loads all products
            band = controller.get_bands()
        else: #loads bands by styles
            band = controller.get_band_by_style(id_styles)
        self.load_bands(band)

    def load_bands_by_search(self):
    #Sets up the Search for a word search
        word = self.ui.search_box.text()
        bandlist = controller.get_bands_name()
        band = controller.search_band(word)
        self.load_bands(band)
        completer = QtGui.QCompleter(bandlist , self)
        completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        completer.setCompletionMode(QtGui.QCompleter.InlineCompletion)
        self.ui.search_box.setCompleter(completer)

    def set_listeners(self):
    #Sets up button listeners
        self.ui.selectStyle.activated[int].connect(self.load_bands_by_style)
        self.ui.search_box.textChanged.connect(self.load_bands_by_search) 
        self.ui.btn_delete.clicked.connect(self.delete)
        self.ui.btn_new.clicked.connect(self.show_add_form)
        self.ui.btn_edit.clicked.connect(self.show_edit_form)

    def show_add_form(self):
    #Displays the add bands screen
        form = view_form.Form(self)
        form.rejected.connect(self.load_bands)
        form.exec_()


    def show_edit_form(self):
    #Displays the edit bands screen
        model = self.ui.table.model()
        index = self.ui.table.currentIndex()
        if index.row() == -1: #No row selected
            self.ui.msgBox = QtGui.QMessageBox.information(self, u'Error',
                                    u"Debe seleccionar la fila que desea editar")
            return False
        else:
            bands = model.index(index.row(), 0, QtCore.QModelIndex()).data()
            form = view_form.Form(self, bands)
            form.rejected.connect(self.load_bands)
            form.exec_()

    def delete(self):
    #Calls on controller to delete a band row on the database
        model = self.ui.table.model()
        index = self.ui.table.currentIndex()
        if index.row() == -1: #No row selected
            self.ui.errorMessageDialog = QtGui.QMessageBox.information(self, 'Error', 
                                        u"Debe seleccionar la fila que desea eliminar", 
                                        QtGui.QMessageBox.Ok, QtGui.QMessageBox.Ok)
            return False
        else:
            self.ui.confirmMessage = QtGui.QMessageBox.question(self, 'Borrar banda',
                                    u"Está seguro que desea eliminar la banda seleccionada?",
                                    QtGui.QMessageBox.Yes | QtGui.QMessageBox.No, 
                                    QtGui.QMessageBox.No)

            if self.ui.confirmMessage == QtGui.QMessageBox.Yes:#Confirmation
                bands = model.index(index.row(), 0, QtCore.QModelIndex()).data()
                if (controller.delete(bands)):
                    self.load_bands()
                    self.ui.msgBox = QtGui.QMessageBox.information(self, u'Información',
                                    u"El registro fue eliminado con éxito")
                    return True
                else:
                    self.ui.errorMessageDialog = QtGui.QMessageBox.information(self, 'Error',
                                                u"Error al eliminar el registro",
                                                QtGui.QMessageBox.Ok, QtGui.QMessageBox.Ok)
                    return False


def run():
#Starts UI loop
    app = QtGui.QApplication(sys.argv)
    main = Main()
    sys.exit(app.exec_())


if __name__ == '__main__':
    run()





